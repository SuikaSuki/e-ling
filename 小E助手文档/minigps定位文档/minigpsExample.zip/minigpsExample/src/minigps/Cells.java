package minigps;

public class Cells {
	int mcc;
	int mnc;
	int lac;
	int cellid;
	int sdb;
	
	public int getSdb() {
		return sdb;
	}
	public void setSdb(int sdb) {
		this.sdb = sdb;
	}
	public int getMcc() {
		return mcc;
	}
	public void setMcc(int mcc) {
		this.mcc = mcc;
	}
	public int getMnc() {
		return mnc;
	}
	public void setMnc(int mnc) {
		this.mnc = mnc;
	}
	public int getLac() {
		return lac;
	}
	public void setLac(int lac) {
		this.lac = lac;
	}
	public int getCellid() {
		return cellid;
	}
	public void setCellid(int cellid) {
		this.cellid = cellid;
	}
	
	
}
