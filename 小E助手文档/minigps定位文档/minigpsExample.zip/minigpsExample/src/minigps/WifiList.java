package minigps;

import java.util.List;

public class WifiList {
	List<WI> ws;

	public List<WI> getWs() {
		return ws;
	}

	public void setWs(List<WI> ws) {
		this.ws = ws;
	}
}
