/*
 * Debugform.java
 *
 * Created on __DATE__, __TIME__
 */

package minigps.ui;

import java.util.ArrayList;
import java.util.List;

import minigps.JsonUtil;
import minigps.LocRadiusPoiResponse;
import minigps.RemoteUtil;
import minigps.WI;
import minigps.WifiAddressConverter;
import minigps.WifiList;

/**
 *
 * @author  __USER__
 */
public class Debugform extends java.awt.Frame {

	/** Creates new form Debugform */
	public Debugform() {
		initComponents();
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		outputPanel = new javax.swing.JPanel();
		outputContent = new javax.swing.JTextArea();
		inputPanel = new javax.swing.JPanel();
		urlPath = new javax.swing.JPanel();
		path = new javax.swing.JLabel();
		pathcontent = new javax.swing.JTextField();
		wifiPanel = new javax.swing.JPanel();
		wifilistPanel = new javax.swing.JPanel();
		wifilist = new javax.swing.JLabel();
		wifi1 = new javax.swing.JTextField();
		jLabel1 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		wifi2 = new javax.swing.JTextField();
		jLabel3 = new javax.swing.JLabel();
		wifi3 = new javax.swing.JTextField();
		jLabel4 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jLabel6 = new javax.swing.JLabel();
		wifi4 = new javax.swing.JTextField();
		wifi5 = new javax.swing.JTextField();
		wifi6 = new javax.swing.JTextField();
		bodyPanel1 = new javax.swing.JPanel();
		body = new javax.swing.JLabel();
		bodycontent = new javax.swing.JTextArea();
		controlPanel = new javax.swing.JPanel();
		isNumber = new javax.swing.JCheckBox();
		formatwifi = new java.awt.Button();
		submit = new java.awt.Button();

		setBackground(java.awt.Color.lightGray);
		setTitle("minigps cell&wifi debug tool");
		addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent evt) {
				exitForm(evt);
			}
		});

		outputPanel.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(236, 233, 216)));
		outputPanel.setAutoscrolls(true);

		outputContent.setColumns(20);
		outputContent.setEditable(false);
		outputContent.setLineWrap(true);
		outputContent.setRows(5);
		outputContent.setText("output:");
		outputContent.setMinimumSize(new java.awt.Dimension(4, 48));

		javax.swing.GroupLayout outputPanelLayout = new javax.swing.GroupLayout(
				outputPanel);
		outputPanel.setLayout(outputPanelLayout);
		outputPanelLayout
				.setHorizontalGroup(outputPanelLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								outputPanelLayout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(
												outputContent,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												704, Short.MAX_VALUE)
										.addContainerGap()));
		outputPanelLayout.setVerticalGroup(outputPanelLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addComponent(outputContent,
						javax.swing.GroupLayout.Alignment.TRAILING,
						javax.swing.GroupLayout.DEFAULT_SIZE, 93,
						Short.MAX_VALUE));

		outputContent.getAccessibleContext().setAccessibleParent(outputPanel);

		add(outputPanel, java.awt.BorderLayout.CENTER);

		inputPanel.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(236, 233, 216)));
		inputPanel.setLayout(new javax.swing.BoxLayout(inputPanel,
				javax.swing.BoxLayout.PAGE_AXIS));

		urlPath.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(236, 233, 216)));
		urlPath.setAlignmentY(1.0F);
		urlPath.setPreferredSize(new java.awt.Dimension(620, 40));

		path.setText("Path:");

		pathcontent
				.setText("http://minigps.net/cw?p=1&mt=0&needaddress=0&x=0-0-0-0-0");
		pathcontent.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				pathcontentActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout urlPathLayout = new javax.swing.GroupLayout(
				urlPath);
		urlPath.setLayout(urlPathLayout);
		urlPathLayout
				.setHorizontalGroup(urlPathLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								urlPathLayout
										.createSequentialGroup()
										.addGap(10, 10, 10)
										.addComponent(
												path,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												30,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(
												pathcontent,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												664, Short.MAX_VALUE)
										.addContainerGap()));
		urlPathLayout
				.setVerticalGroup(urlPathLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								urlPathLayout
										.createSequentialGroup()
										.addGroup(
												urlPathLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																pathcontent,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																38,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(path))
										.addContainerGap(
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)));

		inputPanel.add(urlPath);

		wifiPanel.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(236, 233, 216)));
		wifiPanel.setAlignmentY(1.2F);

		wifilistPanel.setLayout(new java.awt.FlowLayout(
				java.awt.FlowLayout.LEFT));

		wifilist.setText("wifilist:");
		wifilistPanel.add(wifilist);

		jLabel1.setText("wifi1:");

		jLabel2.setText("wifi2:");

		jLabel3.setText("wifi3:");

		jLabel4.setText("wifi6:");

		jLabel5.setText("wifi4:");

		jLabel6.setText("wifi5:");

		javax.swing.GroupLayout wifiPanelLayout = new javax.swing.GroupLayout(
				wifiPanel);
		wifiPanel.setLayout(wifiPanelLayout);
		wifiPanelLayout
				.setHorizontalGroup(wifiPanelLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								wifiPanelLayout
										.createSequentialGroup()
										.addGroup(
												wifiPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																wifiPanelLayout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addGroup(
																				wifiPanelLayout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabel1)
																						.addComponent(
																								jLabel2))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				wifiPanelLayout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								wifi1,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								662,
																								Short.MAX_VALUE)
																						.addComponent(
																								wifi2,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								662,
																								Short.MAX_VALUE)))
														.addGroup(
																wifiPanelLayout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(
																				jLabel3)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				wifi3,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				662,
																				Short.MAX_VALUE))
														.addGroup(
																wifiPanelLayout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(
																				jLabel5)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				wifi4,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				662,
																				Short.MAX_VALUE))
														.addGroup(
																wifiPanelLayout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(
																				jLabel6)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				wifi5,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				662,
																				Short.MAX_VALUE))
														.addGroup(
																wifiPanelLayout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(
																				jLabel4)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				wifi6,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				662,
																				Short.MAX_VALUE))
														.addComponent(
																wifilistPanel,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																712,
																Short.MAX_VALUE))
										.addContainerGap()));
		wifiPanelLayout
				.setVerticalGroup(wifiPanelLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								wifiPanelLayout
										.createSequentialGroup()
										.addComponent(
												wifilistPanel,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												wifiPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel1)
														.addComponent(
																wifi1,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addGroup(
												wifiPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel2)
														.addComponent(
																wifi2,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												wifiPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel3)
														.addComponent(
																wifi3,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addGroup(
												wifiPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel5)
														.addComponent(
																wifi4,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addGroup(
												wifiPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel6)
														.addComponent(
																wifi5,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)
										.addGroup(
												wifiPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel4)
														.addComponent(
																wifi6,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))));

		inputPanel.add(wifiPanel);

		bodyPanel1.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(236, 233, 216)));
		bodyPanel1.setAlignmentY(1.5F);

		body.setText("Body:");

		bodycontent.setColumns(20);
		bodycontent.setLineWrap(true);
		bodycontent.setRows(5);

		javax.swing.GroupLayout bodyPanel1Layout = new javax.swing.GroupLayout(
				bodyPanel1);
		bodyPanel1.setLayout(bodyPanel1Layout);
		bodyPanel1Layout
				.setHorizontalGroup(bodyPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								bodyPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(body)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(
												bodycontent,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												662, Short.MAX_VALUE)
										.addContainerGap()));
		bodyPanel1Layout
				.setVerticalGroup(bodyPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								bodyPanel1Layout
										.createSequentialGroup()
										.addGroup(
												bodyPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																bodyPanel1Layout
																		.createSequentialGroup()
																		.addGap(47,
																				47,
																				47)
																		.addComponent(
																				body))
														.addComponent(
																bodycontent,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addContainerGap(
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)));

		inputPanel.add(bodyPanel1);

		add(inputPanel, java.awt.BorderLayout.NORTH);

		controlPanel.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(0, 0, 0)));

		isNumber.setText("isNumber");
		controlPanel.add(isNumber);

		formatwifi.setLabel("formatwifi");
		formatwifi.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				formatwifiActionPerformed(evt);
			}
		});
		controlPanel.add(formatwifi);

		submit.setActionCommand("submit");
		submit.setLabel("submit");
		submit.setName("submit");
		submit.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				submitActionPerformed(evt);
			}
		});
		controlPanel.add(submit);

		add(controlPanel, java.awt.BorderLayout.SOUTH);

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void pathcontentActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void formatwifiActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		boolean isNumberValue = isNumber.isSelected();
		List<WI> wis = new ArrayList<WI>();
		String wifi1Str = wifi1.getText();
		if (wifi1Str != null) {
			wifi1Str = wifi1Str.trim();
		}

		String wifi2Str = wifi2.getText();
		if (wifi2Str != null) {
			wifi2Str = wifi2Str.trim();
		}

		String wifi3Str = wifi3.getText();
		if (wifi3Str != null) {
			wifi3Str = wifi3Str.trim();
		}

		String wifi4Str = wifi4.getText();
		if (wifi4Str != null) {
			wifi4Str = wifi4Str.trim();
		}

		String wifi5Str = wifi5.getText();
		if (wifi5Str != null) {
			wifi5Str = wifi5Str.trim();
		}

		String wifi6Str = wifi6.getText();
		if (wifi6Str != null) {
			wifi6Str = wifi6Str.trim();
		}

		if (isNumberValue) {
			if (wifi1Str != null && wifi1Str.length() > 0) {
				WI wi = new WI();
				wi.setM(Long.parseLong(wifi1Str));
				wi.setR(65);
				wi.setS("minigpstest");
				wis.add(wi);
			}

			if (wifi2Str != null && wifi2Str.length() > 0) {
				WI wi = new WI();
				wi.setM(Long.parseLong(wifi2Str));
				wi.setR(65);
				wi.setS("minigpstest");
				wis.add(wi);
			}

			if (wifi3Str != null && wifi3Str.length() > 0) {
				WI wi = new WI();
				wi.setM(Long.parseLong(wifi3Str));
				wi.setR(65);
				wi.setS("minigpstest");
				wis.add(wi);
			}

			if (wifi4Str != null && wifi4Str.length() > 0) {
				WI wi = new WI();
				wi.setM(Long.parseLong(wifi4Str));
				wi.setR(65);
				wi.setS("minigpstest");
				wis.add(wi);
			}

			if (wifi5Str != null && wifi5Str.length() > 0) {
				WI wi = new WI();
				wi.setM(Long.parseLong(wifi5Str));
				wi.setR(65);
				wi.setS("minigpstest");
				wis.add(wi);
			}

			if (wifi6Str != null && wifi6Str.length() > 0) {
				WI wi = new WI();
				wi.setM(Long.parseLong(wifi6Str));
				wi.setR(65);
				wi.setS("minigpstest");
				wis.add(wi);
			}
		} else {
			if (wifi1Str != null && wifi1Str.length() > 0) {
				WI wi = new WI();
				wi.setM(WifiAddressConverter.Str2Long(wifi1Str));
				wi.setR(65);
				wi.setS("minigpstest");
				wis.add(wi);
			}

			if (wifi2Str != null && wifi2Str.length() > 0) {
				WI wi = new WI();
				wi.setM(WifiAddressConverter.Str2Long(wifi2Str));
				wi.setR(65);
				wi.setS("minigpstest");
				wis.add(wi);
			}

			if (wifi3Str != null && wifi3Str.length() > 0) {
				WI wi = new WI();
				wi.setM(WifiAddressConverter.Str2Long(wifi3Str));
				wi.setR(65);
				wi.setS("minigpstest");
				wis.add(wi);
			}

			if (wifi4Str != null && wifi4Str.length() > 0) {
				WI wi = new WI();
				wi.setM(WifiAddressConverter.Str2Long(wifi4Str));
				wi.setR(65);
				wi.setS("minigpstest");
				wis.add(wi);
			}

			if (wifi5Str != null && wifi5Str.length() > 0) {
				WI wi = new WI();
				wi.setM(WifiAddressConverter.Str2Long(wifi5Str));
				wi.setR(65);
				wi.setS("minigpstest");
				wis.add(wi);
			}

			if (wifi6Str != null && wifi6Str.length() > 0) {
				WI wi = new WI();
				wi.setM(WifiAddressConverter.Str2Long(wifi6Str));
				wi.setR(65);
				wi.setS("minigpstest");
				wis.add(wi);
			}
		}

		String w = null;
		if (wis != null && wis.size() > 0) {
			WifiList wlist = new WifiList();
			wlist.setWs(wis);
			w = JsonUtil.toJson(wlist);
		}
		if (w != null) {
			bodycontent.setText(w);
		}
	}

	private void submitActionPerformed(java.awt.event.ActionEvent evt) {
		String result = null;
		String url = pathcontent.getText();
		String w = bodycontent.getText();
		if (w != null && w.length() > 0) {
			result = RemoteUtil.request(url, "POST",
					"application/json;charset=utf-8", w);
		} else {
			result = RemoteUtil.request(url, "GET",
					"application/json;charset=utf-8", null);
		}
		if (result != null) {
			System.out.print(result);
		}

		outputContent.setText(result);
	}

	/** Exit the Application */
	private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
		System.exit(0);
	}//GEN-LAST:event_exitForm

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Debugform().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JLabel body;
	private javax.swing.JPanel bodyPanel1;
	private javax.swing.JTextArea bodycontent;
	private javax.swing.JPanel controlPanel;
	private java.awt.Button formatwifi;
	private javax.swing.JPanel inputPanel;
	private javax.swing.JCheckBox isNumber;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JTextArea outputContent;
	private javax.swing.JPanel outputPanel;
	private javax.swing.JLabel path;
	private javax.swing.JTextField pathcontent;
	private java.awt.Button submit;
	private javax.swing.JPanel urlPath;
	private javax.swing.JTextField wifi1;
	private javax.swing.JTextField wifi2;
	private javax.swing.JTextField wifi3;
	private javax.swing.JTextField wifi4;
	private javax.swing.JTextField wifi5;
	private javax.swing.JTextField wifi6;
	private javax.swing.JPanel wifiPanel;
	private javax.swing.JLabel wifilist;
	private javax.swing.JPanel wifilistPanel;
	// End of variables declaration//GEN-END:variables

}